# Paths

Lumi uses these paths to store files:

MacOS: ~/Library/Application Support/lumi